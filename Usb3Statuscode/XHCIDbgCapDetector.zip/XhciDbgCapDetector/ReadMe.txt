How to Find the XHCI Debug Port:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Using the XhciDbgCapDetector Shell Application
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

a) Install the "USB 3.0 Debug Cable" Driver on the Host side 

b) Connect one end of the "USB 3.0 Debug Cable" to a USB 3.0 port on host side

c) In Target side, Boot to Shell without the "USB 3.0 Debug Cable" connected.

d) Run the XhciDbgCapDetector_x64 or XhciDbgCapDetector_x86 EFI application from Shell based on the arch.

e) If the Platform Supports XHCI Debug Capability
	XHCI Debug Capability [Found] will be displayed
   if not
   	XHCI Debug Capability [Not Found] will be displayed
   
f) If Debug Capability is Supported
	- Connect the other End of the "USB 3.0 Debug Cable" on a Targetside USB 3.0 port
	- If that port is the XHCI Debug Port
	  The Cable will be visible on the Host's Device Manager 
	- If not, try another USB 3.0 port

