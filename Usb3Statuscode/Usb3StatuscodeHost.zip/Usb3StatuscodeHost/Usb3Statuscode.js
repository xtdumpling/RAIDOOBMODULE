var WindowStyle_Hidden = 1
var objShell = WScript.CreateObject("WScript.Shell")
var result = objShell.Run("cmd.exe /C usb3statuscode.bat", WindowStyle_Hidden)
WScript.Quit (1)
