Contents

HostApp - Host application for USB 3 Statuscode.

Steps

Host side
1) Install the USB 3 Debug driver provided in Usb3Statuscode eModule 
2) Use the USB 3 Debug cable in USB 3 port with Driver provided by AMI.
3) Launch Usb3Statuscode.js.

Target Connection
1) Include Usb3Statuscode module.
2) Use the USB 3 debug cable in USB 3 debug Capability port 
3) Power On Target


