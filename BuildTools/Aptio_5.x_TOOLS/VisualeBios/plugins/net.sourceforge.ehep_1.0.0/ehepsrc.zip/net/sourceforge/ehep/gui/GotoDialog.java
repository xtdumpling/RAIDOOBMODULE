/*==========================================================================
 * 
 * GotoDialog.java
 * 
 * $Author: uwe_ewald $
 * $Revision: 1.4 $
 * $Date: 2011/05/17 21:04:27 $
 * $Name:  $
 * 
 * Created on 2-Feb-2004
 * Created by Marcel Palko alias Randallco (randallco@users.sourceforge.net)
 *==========================================================================*/
package net.sourceforge.ehep.gui;

import net.sourceforge.ehep.core.EHEP;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * @author Marcel Palko
 * @author randallco@users.sourceforge.net
 */
public class GotoDialog extends Dialog {
	private Button btnDecAddress;
	private Button btnHexAddress;
	private Text txtAddress;
	private Button btnAbsoluteMode;
	private Button btnRelativeDownMode;
	private Button btnRelativeUpMode;
	private int rowIndex;
	private int columnIndex;
	private HexTablePointer newPosition;
		
	public GotoDialog(Shell parent, int rowIndex, int columnIndex) {
		super(parent);
		this.rowIndex = rowIndex;
		this.columnIndex = columnIndex;
	}
	
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Go to address");
	}
	
	public HexTablePointer getNewPosition() {
		return newPosition;
	}
	
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite control = (Composite) super.createDialogArea(parent);

		//
		// Panel with user input components
		//
		Composite inputPanel = new Composite(control, SWT.NONE);
		GridLayout inputGrid = new GridLayout();
		inputGrid.numColumns = 2;
		inputGrid.marginHeight = 0;
		inputGrid.marginWidth = 0;
		inputGrid.horizontalSpacing = 5;
		inputPanel.setLayout(inputGrid);
		inputPanel.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_FILL));

		//
		// Panel with "Go to" address
		//
		Composite addressPanel = new Composite(inputPanel, SWT.NONE);
		GridLayout addressGrid = new GridLayout();
		addressGrid.numColumns = 1;
		addressPanel.setLayout(addressGrid);
		addressPanel.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_FILL));
		createAddressPanel(addressPanel);
		
		//
		// Panel with "Go to" mode
		//
		Composite modePanel = new Composite(inputPanel, SWT.NONE);
		GridLayout modeGrid = new GridLayout();
		modeGrid.numColumns = 1;
		modePanel.setLayout(modeGrid);
		modePanel.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_FILL));
		createModePanel(modePanel);

		return control;
	}

	private void createAddressPanel(Composite parent) {
		Group addressGroup = new Group(parent, SWT.NONE);
		addressGroup.setLayoutData(new GridData(GridData.FILL_VERTICAL));
		addressGroup.setText("Address");
		GridLayout addressLayout = new GridLayout();
		addressLayout.numColumns = 1;
		addressGroup.setLayout(addressLayout);

		btnDecAddress = new Button(addressGroup, SWT.RADIO);
		btnDecAddress.setText("Decimal");
		btnDecAddress.setSelection(true);

		btnHexAddress = new Button(addressGroup, SWT.RADIO);
		btnHexAddress.setText("Hexadecimal");
		btnHexAddress.setSelection(false);

		txtAddress = new Text(addressGroup, SWT.SINGLE | SWT.BORDER);
		txtAddress.setTextLimit(9);
		txtAddress.setText("000000000"); // To make this widget wide enough (see Bug #1277533)
		txtAddress.setFocus();
		
		txtAddress.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				String addr = txtAddress.getText();
				
				if (addr != null && addr.compareTo("000000000") == 0) {
					txtAddress.setText("");
					txtAddress.setTextLimit(8);
				}
			}
			
			public void focusLost(FocusEvent e) {}
		});
	}

	private void createModePanel(Composite parent) {
		Group modeGroup = new Group(parent, SWT.NONE);
		modeGroup.setLayoutData(new GridData(GridData.FILL_VERTICAL));
		modeGroup.setText("Mode");
		GridLayout modeLayout = new GridLayout();
		modeLayout.numColumns = 1;
		modeGroup.setLayout(modeLayout);

		btnAbsoluteMode = new Button(modeGroup, SWT.RADIO);
		btnAbsoluteMode.setText("Absolute");
		btnAbsoluteMode.setSelection(true);

		btnRelativeDownMode = new Button(modeGroup, SWT.RADIO);
		btnRelativeDownMode.setText("Relative down");
		btnRelativeDownMode.setSelection(false);

		btnRelativeUpMode = new Button(modeGroup, SWT.RADIO);
		btnRelativeUpMode.setText("Relative up");
		btnRelativeUpMode.setSelection(false);
	}
	
	@Override
	protected void okPressed() {
		//
		// Check the user input
		//
		int iAddress = 0;
		String sAddress = txtAddress.getText();
		boolean addressIsDec = btnDecAddress.getSelection();
		newPosition = null;
		
		if (sAddress.length() == 0) {
			MessageDialog.openError(getShell(), EHEP.DIALOG_TITLE_ERROR, "Address is missing!");
			txtAddress.setFocus();
			return;
		} // if
		
		try {
			iAddress = Integer.parseInt(sAddress, (addressIsDec) ? 10 : 16);
		}
		catch (NumberFormatException nfeSize) {
			MessageDialog.openError(getShell(), EHEP.DIALOG_TITLE_ERROR, "Address: Incorrect number format!\nPlease enter a valid " + ((addressIsDec) ? "decimal" : "hexadecimal") + " number.");
			txtAddress.setFocus();
			txtAddress.selectAll();
			return;
		}
				
		if (iAddress < 0) {
			MessageDialog.openError(getShell(), EHEP.DIALOG_TITLE_ERROR, "Address cannot be negative!");
			txtAddress.setFocus();
			txtAddress.selectAll();
			return;
		} // if

		//
		// Calculate new position (offset)
		//
		if (btnAbsoluteMode.getSelection()) {
			//
			// 'Absolute mode' selected
			//
			newPosition = new HexTablePointer(0, 0).move(iAddress);
		} // if
		else {
			//
			// 'Relative mode' selected
			//
			if (btnRelativeDownMode.getSelection()) {
				newPosition = new HexTablePointer(rowIndex, columnIndex).move(iAddress-1);
			}
			else {
				newPosition = new HexTablePointer(rowIndex, columnIndex).move(-iAddress-1);
			}
		} // else
		super.okPressed();
	}
}
