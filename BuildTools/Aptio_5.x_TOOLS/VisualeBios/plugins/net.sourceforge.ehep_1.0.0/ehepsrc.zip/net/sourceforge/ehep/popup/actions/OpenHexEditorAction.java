package net.sourceforge.ehep.popup.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

public class OpenHexEditorAction implements IObjectActionDelegate {
	protected IFile file;
	/**
	 * Constructor for Action1.
	 */
	public OpenHexEditorAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
	    IWorkbenchWindow workbenchWindow = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
	    IWorkbenchPage page = workbenchWindow.getActivePage();

	    // Open an editor on the new file.
	    //
	    try
	    {
	      page.openEditor
	        (new FileEditorInput(file), 
	          "net.sourceforge.ehep.editors.HexEditor");
	    }
	    catch (PartInitException exception)
	    {
	      MessageDialog.openError(workbenchWindow.getShell(), "Open Editor", exception.getMessage());
	    }
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	    if (selection instanceof IStructuredSelection)
	    {
	      Object object = ((IStructuredSelection)selection).getFirstElement();
	      if (object instanceof IFile)
	      {
	        file = (IFile)object;
	        return;
	      }
	    }
	    file = null;
	    action.setEnabled(false);
	}

}
