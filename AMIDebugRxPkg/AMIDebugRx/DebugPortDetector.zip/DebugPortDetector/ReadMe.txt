How to Find the USB Debug Port:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



Using the DebugPortdetector Shell Application
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

a) Boot to Shell without AMIdebugRx connected to target.

b) Run the  DebugPortDetectorX64 or DebugPortDetectorX86 EFI application from Shell based on the arch.

c) If a USB Device is detected in the Debug port then 
   "A USB Device is DETECTED In DebugPort" message will be displayed.
   Also the device type connected will be displayed (Eg: AMI DEBUG Rx or USB Optical Mouse etc).

d) If No USB device is detected in the debug port then it will show the message as 
   "No USB Device is DETECTED In the DebugPort". 
   Now connect the device to some other USB port and press "ENTER" key to check if the debug port is detected.

f) Press "ESC" key to exit the application.

NOTE: If the user has tried in all the USB ports and is yet to identify the Debug port, 
      this could mean that the USB Debug Port is probably available as an On board PIN, 
      Please refer to the Board Specification to confirm the USB Debug port location and 
      if it is an On-board PIN then verify the correct pin configuration. 
      Connecting AMI Debug Rx or any USB Device with the incorrect PIN setup could damage the USB Device.


Special BIOS (Polling method)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
With This Method user can build the BIOS project with below mwntioned SDL setup, 
so that on connecting the AMI Debug Rx Device to any USB Port and power ON the target,
if the USB port connected is the Debug port the user will be notified via AMI Debug Rx Device.

a) Build and Flash the BIOS project with AMIDebugRx module enabled with the following SDL token Setup
	1) DEBUG_PORT_DETECTION_MODE - ON (will be OFF by default, ON it to build it in Port detction mode)
	2) DEBUG_PORT_DETECTION_TIMEOUT - 0xXXXX 
	   This SDL Token determines the Timeout for the Module to Poll Checkpoint 0xDD to the USB Debug Port,
	   Default Value is 0x1770 to pol for a Min, to rules to Set to custom time is described in the SDL token Help.
	   [How to Set Timeout value - 0xDD Checkpoint happens in interval of 10mSec, so for 1 sec timeout you will need 
           (1000/10=100)0x3e8/0xa=0x64. Default set for 0x1770 = 1 min]

b) Connect the AMIDebugRx device to any USB port in target and power ON the target.
d) If the connected USB port is the debug port then the AMI Debug Rx device screen will show checkpoint "DD" for some time based on the timeout. 
e) Try the same process for all USB ports available in the platform to find out the Debug port.

NOTE: If the user has tried in all the USB ports and is yet to identify the Debug port, 
      this could mean that the USB Debug Port is probably available as an On board PIN, 
      Please refer to the Board Specification to confirm the USB Debug port location and 
      if it is an On-board PIN then verify the correct pin configuration. 
      Connecting AMI Debug Rx or any USB Device with the incorrect PIN setup could damage the USB Device.